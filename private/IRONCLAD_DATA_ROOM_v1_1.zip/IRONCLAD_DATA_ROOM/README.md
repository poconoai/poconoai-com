# IRONCLAD DATA ROOM

Pocono AI, LLC investor diligence package.

This ZIP contains the currently completed PDF files organized into the original IRONCLAD Data Room folder structure.

Founder Contact:

Marcus O'Dell
Founder & CEO
Pocono AI, LLC
marcus@poconoai.com
(570) 534-0602
https://poconoai.com
