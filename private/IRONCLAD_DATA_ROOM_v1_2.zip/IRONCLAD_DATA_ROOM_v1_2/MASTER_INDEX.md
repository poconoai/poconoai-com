# IRONCLAD DATA ROOM — MASTER INDEX
**Pocono AI, LLC | Version 1.2 | CONFIDENTIAL**

---

## Section 01 — Executive

| Document | File |
|---|---|
| Executive Summary | 01_Executive/PoconoAI_Executive_Summary_v1_2.pdf |
| Founder Letter | 01_Executive/PoconoAI_Founder_Letter_v1_2.pdf |
| Investor FAQ | 01_Executive/PoconoAI_Investor_FAQ_v1_2.pdf |
| One-Page Overview | 01_Executive/PoconoAI_One_Page_Overview_v1_2.pdf |
| Pitch Deck Outline | 01_Executive/PoconoAI_Pitch_Deck_Outline_v1_2.pdf |

## Section 03 — Product

| Document | File |
|---|---|
| Sentinel Node™ Overview | 03_Product/PoconoAI_Sentinel_Node_Overview_v1_2.pdf |

## Section 04 — Architecture

| Document | File |
|---|---|
| Technical Architecture Overview | 04_Architecture/PoconoAI_Technical_Architecture_v1_2.pdf |
| Retrieval & Audit Pipeline | 04_Architecture/PoconoAI_Retrieval_Audit_Pipeline_v1_2.pdf |
| Security & Threat Model | 04_Architecture/PoconoAI_Security_Threat_Model_v1_2.pdf |

## Section 05 — Governance & Compliance

| Document | File |
|---|---|
| Governance Framework | 05_Governance_and_Compliance/PoconoAI_Governance_Framework_v1_2.pdf |
| HIPAA Positioning | 05_Governance_and_Compliance/PoconoAI_HIPAA_Positioning_v1_2.pdf |
| Attorney-Client Privilege Positioning | 05_Governance_and_Compliance/PoconoAI_Attorney_Client_Privilege_Positioning_v1_2.pdf |
| AI Governance Charter | 05_Governance_and_Compliance/PoconoAI_AI_Governance_Charter_v1_2.pdf |
| Business Continuity Plan | 05_Governance_and_Compliance/PoconoAI_Business_Continuity_Plan_v1_2.pdf |
| Incident Response Plan | 05_Governance_and_Compliance/PoconoAI_Incident_Response_Plan_v1_2.pdf |

## Section 06 — Healthcare

| Document | File |
|---|---|
| Healthcare Pilot Program | 06_Healthcare/PoconoAI_Healthcare_Pilot_Program_v1_2.pdf |
| Prior Authorization Workflow | 06_Healthcare/PoconoAI_Prior_Authorization_Workflow_v1_2.pdf |

## Section 07 — Legal Sector

| Document | File |
|---|---|
| Law Firm Pilot Program | 07_Legal_Sector/PoconoAI_Law_Firm_Pilot_Program_v1_2.pdf |
| Legal Research Workflow | 07_Legal_Sector/PoconoAI_Legal_Research_Workflow_v1_2.pdf |

## Section 09 — Financials

| Document | File |
|---|---|
| Pricing Overview | 09_Financials/PoconoAI_Pricing_Overview_v1_2.pdf |
| Use of Funds | 09_Financials/PoconoAI_Use_of_Funds_v1_2.pdf |
| Revenue Model | 09_Financials/PoconoAI_Revenue_Model_v1_2.pdf |
| Three-Year Forecast Template | 09_Financials/PoconoAI_Three_Year_Forecast_Template_v1_2.pdf |

---

*Confidential. Prepared for investor diligence purposes only. Not for distribution.*
*Pocono AI, LLC | marcus@poconoai.com | (570) 534-0602 | https://poconoai.com*
